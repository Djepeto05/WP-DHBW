class Products {

    baseUrl = 'http://localhost/2023/products.php';

    constructor() {

    }

    async getAllProducts() {
        const response = await fetch(`${this.baseUrl}?products=1`);
        const result = await response.json();
        return result;
    }

    async getProductById(id) {
        const response = await fetch(`${this.baseUrl}?id=${id}`);
        const result = await response.json();
        return result;
    }
}