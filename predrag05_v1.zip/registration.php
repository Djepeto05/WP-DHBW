<?php
    session_start();
    include('config.php');
    if (isset($_POST)) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        $query = $connection->prepare("SELECT * FROM users WHERE email=:email");
        $query->bindParam("email", $email, PDO::PARAM_STR);
        $query->execute();
        if ($query->rowCount() > 0) {
            header("Location: signin.html?msg=The email address is already registered!");
        }
        if ($query->rowCount() == 0) {
            $query = $connection->prepare("INSERT INTO users(name,password,email) VALUES (:name,:password_hash,:email)");
            $query->bindParam("name", $name, PDO::PARAM_STR);
            $query->bindParam("password_hash", $password_hash, PDO::PARAM_STR);
            $query->bindParam("email", $email, PDO::PARAM_STR);
            $result = $query->execute();
            if ($result) {
                header("Location: signin.html?msg=Your registration was successful!");
            } else {
                header("Location: signin.html?msg=Something went wrong!");
            }
        }
    }
?>