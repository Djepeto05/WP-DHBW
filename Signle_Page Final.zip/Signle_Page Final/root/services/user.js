class User {

    baseUrl = 'http://localhost/2023/user.php';

    constructor() {

    }

    async getDatabaseUserById(id) {
        const response = await fetch(`${this.baseUrl}?id=${id}&user_id=${id}`);
        const result = await response.json();
        return result;
    }

    async getUserContent(newContent) {
        const response = await fetch(`${this.baseUrl}?${newContent}`);
        const result = await response.json();
        return result;
    }
}