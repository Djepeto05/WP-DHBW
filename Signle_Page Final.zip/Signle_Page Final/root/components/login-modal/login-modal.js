class LoginModal {
    onClickCallback;
    user;

    constructor(onClick) {
        this.onClickCallback = onClick;
        this.user = new User();
    }

    render(parentSelector) {
        this.loadModal(parentSelector).then(() => {
            const loginModal = new bootstrap.Modal('#loginModal', {});
            loginModal.show();
            this.setupLoginForm(loginModal);
        });
    }

    loadModal(parentSelector) {
        return new Promise((resolve) => {
            $(parentSelector).load('./components/login-modal/login-modal.html', () => {
                resolve();
            });
        });
    }

    setupLoginForm(loginModal) {
        const wrongCredentials = $('#errorMsg');
        const loginForm = $('#login-form');
        loginForm.on('submit', (event) => {
            event.preventDefault();
            const signin = this.buildSignInObject();
            this.attemptLogin(signin, loginModal, wrongCredentials);
        });
    }

    buildSignInObject() {
        return 'email=' + $('#form-email').val() + '&' + 'password=' + $('#form-password').val() + '&' + 'login=1';
    }

    attemptLogin(signin, loginModal, wrongCredentials) {
        this.user.getUserContent(signin).then((res) => {
            if (typeof res === 'object' && res !== null) {
                wrongCredentials.addClass('error');
                this.loginSuccess(res.id, loginModal);
            } else {
                wrongCredentials.removeClass('error');
            }
        });
    }

    loginSuccess(userid, loginModal) {
        this.user.getDatabaseUserById(userid).then((res) => {
            sessionStorage.setItem('customerID', res.id);
            loginModal.hide();
            this.onClickCallback('home');
            new Navigation(navigatePage).render('#navigation');
            alert('Logged in successfully');
        });
    }
}
