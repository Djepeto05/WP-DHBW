class Navigation {
    onClickCallback;
    parentSelector;
    pages;

    constructor(pages, onClick) {
        this.onClickCallback = onClick;
        this.pages = pages;
    }

    render(parentSelector) {
        this.parentSelector = parentSelector;

        // Add reference to style sheet
        $('head').append('<link rel="stylesheet" href="components/navigation/navigation.css">');

        // Load html file async
        $(parentSelector).load('./components/navigation/navigation.html', () => {

            // Register dynamic links to pages
            const pageKeys = Object.keys(this.pages);
            pageKeys.forEach((pageKey) => {
                $(`${parentSelector} .navigation`).append(`<a id="${pageKey}" class="nav-item">${this.pages[pageKey].label}</a>`);
            });

            // Register for click events
            $('.nav-item').on('click', (e) => {
                console.log(`${e.currentTarget.id} was clicked`);

                if (this.onClickCallback)
                    this.onClickCallback(e.currentTarget.id);
            });

            $('#shoppingCart').on('click', (e) => {
                const cartModal = new ShoppingCart(this.onClickCallback);
                cartModal.render($('#modal-container'));
            });

            // Check if user is logged in
            if (!sessionStorage.getItem('customerID')) {

                // Change button to signin
                $('#my-account-sign-in-btn').html('Login');

                // Open Sign-In Modal
                $('#my-account-sign-in-btn').on('click', (e) => {
                    const loginModal = new LoginModal(this.onClickCallback);
                    loginModal.render($('#modal-container'));
                });

            } else {
                // Change button to logout
                $('#my-account-sign-in-btn').html('Log out');

                // Remove register btn
                $('#reg-btn').remove();

                // Clear session storage
                $('#my-account-sign-in-btn').on('click', () => {
                    sessionStorage.clear();
                    location.reload();
                });
            }

            this.renderNavShoppingCart();

            const searchbar = $('#sSearch');
            searchbar.on('click', (e) => {
                const searchbarContent = new SearchbarContent(navigatePage);
                searchbarContent.render('#content');
            });

        });
    }

    renderNavShoppingCart() {
        let shoppingCartProducts = JSON.parse(localStorage.getItem('shopping-cart-products'));
        console.log(shoppingCartProducts);
        if (shoppingCartProducts && 0 < shoppingCartProducts.length) {
            let totalPriceOfSC = 0;
            let totalQuantity = 0;
            shoppingCartProducts.forEach((p) => {
                totalPriceOfSC += parseFloat(p.price) * parseFloat(p.quantity);
                totalQuantity += parseFloat(p.quantity);
            });
            const strTotalPriceOfSC = totalPriceOfSC.toFixed(2).replace('.', ',');

            $('#nav-badge-shopping-cart').html(totalQuantity);
        }
    }
}
