-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 23, 2023 at 12:14 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecom`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `quantity`, `created_at`) VALUES
(4, NULL, NULL, '1', '2023-03-17 11:29:29'),
(5, NULL, NULL, '1', '2023-03-17 11:29:29'),
(6, NULL, NULL, '1', '2023-03-17 11:30:19'),
(7, 4, 34, '1', '2023-03-17 11:31:17'),
(8, 4, 33, '1', '2023-03-17 11:31:17'),
(9, 4, 33, '1', '2023-03-17 11:32:23'),
(10, 4, 34, '1', '2023-03-17 11:32:23'),
(11, 4, 33, '1', '2023-03-17 11:33:56'),
(12, 4, 34, '1', '2023-03-17 11:33:56'),
(13, 4, 34, '1', '2023-03-17 11:34:47'),
(14, 4, 33, '1', '2023-03-17 11:34:47'),
(15, 4, 25, '1', '2023-03-17 23:58:07'),
(16, 4, 38, '1', '2023-03-17 23:58:07'),
(17, 4, 37, '1', '2023-03-18 00:00:00'),
(18, 4, 25, '1', '2023-03-18 00:01:03'),
(19, 4, 25, '1', '2023-03-18 00:03:44'),
(20, 4, 25, '1', '2023-03-20 01:55:28'),
(21, 4, 37, '1', '2023-03-20 01:55:28'),
(22, 4, 26, '1', '2023-03-20 01:55:28'),
(23, 4, 25, '1', '2023-03-20 01:55:28'),
(24, 4, 37, '1', '2023-03-20 01:55:28'),
(25, 4, 26, '1', '2023-03-20 01:55:28'),
(26, 4, 37, '1', '2023-03-20 01:55:28'),
(27, 4, 26, '1', '2023-03-20 01:55:28'),
(28, 4, 28, '1', '2023-03-20 02:05:55'),
(29, 4, 38, '1', '2023-03-20 02:05:55'),
(30, 4, 37, '1', '2023-03-20 17:32:34'),
(31, 4, 28, '1', '2023-03-20 17:32:34'),
(32, 4, 26, '1', '2023-03-22 22:07:01'),
(33, 4, 37, '1', '2023-03-22 22:07:01'),
(34, 4, 25, '1', '2023-03-22 22:07:01'),
(35, 4, 25, '1', '2023-03-22 22:07:01'),
(36, 4, 35, '1', '2023-03-22 22:07:25'),
(37, 4, 35, '1', '2023-03-22 22:09:07'),
(38, 4, 35, '1', '2023-03-22 22:10:05'),
(39, 4, 34, '1', '2023-03-22 22:11:06'),
(40, 4, 34, '1', '2023-03-22 22:11:06'),
(41, 4, 27, '1', '2023-03-22 22:11:41'),
(42, 4, 44, '1', '2023-03-22 22:12:49'),
(43, 4, 40, '1', '2023-03-22 22:13:41'),
(44, 4, 37, '1', '2023-03-22 22:26:59'),
(45, 4, 37, '1', '2023-03-22 22:26:59'),
(46, 37, 4, '1', '2023-03-22 22:51:11'),
(47, 37, 4, '1', '2023-03-22 22:52:06');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `inStock` int(11) NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `img`, `category`, `inStock`, `description`, `created_at`) VALUES
(25, 'Roadster', '30', '1.jpg', 'Tops', 5, 'test description', '2023-03-16 04:39:45'),
(26, 'SASSAFRAS', '60', '2.jpg', 'Tops', 5, 'test description', '2023-03-16 04:48:03'),
(27, 'Darzi', '65', '3.jpg', 'Tops', 5, 'test description', '2023-03-16 04:48:03'),
(28, 'La Zorie', '40', '4.jpg', 'Tops', 5, 'test description', '2023-03-16 04:48:03'),
(29, 'Smarty Pants', '60', '5.jpg', 'Pants', 5, 'test description', '2023-03-16 04:48:03'),
(31, 'Smarty Pants', '40', '1.jpg', 'Pants', 5, 'test description', '2023-03-16 04:48:03'),
(32, 'Puma', '40', '2.jpg', 'Pants', 5, 'test description', '2023-03-16 04:48:03'),
(34, 'Nike', '200', '4.jpg', 'Pants', 5, 'test description', '2023-03-16 04:57:29'),
(35, 'Asian crystal', '80', '5.jpg', 'Pants', 5, 'test description', '2023-03-16 04:57:30'),
(36, 'Shoe sense', '150', '6.jpg', 'Pants', 5, 'test description', '2023-03-16 04:57:30'),
(37, 'La Zorie', '40', '5.jpg', 'Tops', 5, 'test description', '2023-03-16 04:48:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `created_at`) VALUES
(4, 'test', 'amarmotiani2014@gmail.com', '123456', '25f9e794323b453885f5181f1b624d0b', '2023-03-16 23:06:33'),
(10, 'predrag05', 'predrag05@predrag05.com', '123456789', '25f9e794323b453885f5181f1b624d0b', '2023-03-20 07:45:32'),
(11, 'admin', 'admin@admin.com', '123456789', '25f9e794323b453885f5181f1b624d0b', '2023-03-20 07:45:32'),
(12, 'predrag05', 'predrag05@predrag05.com', '123456789', '25f9e794323b453885f5181f1b624d0b', '2023-03-20 07:46:15'),
(13, 'admin', 'admin@admin.com', '123456789', '25f9e794323b453885f5181f1b624d0b', '2023-03-20 07:46:15'),
(14, 'user', 'user@user.com', '123456789', '25f9e794323b453885f5181f1b624d0b', '2023-03-20 07:46:15'),
(15, 'guest', 'guest@guest.com', '123456789', '25f9e794323b453885f5181f1b624d0b', '2023-03-20 07:46:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
