const imagesPath = '../resources/images/';

$(() => {
    Components();
    Pages();
    Services();

    setupLocalStorage();

    const navigation = new Navigation(navigatePage);
    navigation.render('#navigation');

    const home = new Home(navigatePage);
    home.render('#content');

    const footer = new Footer(navigatePage);
    footer.render('#footer');

});



function setupLocalStorage() {
    if (typeof (Storage) !== "undefined") {
        let shoppingCartProducts = JSON.stringify(localStorage.getItem('shopping-cart-products'));
        if (shoppingCartProducts == 'null')
            localStorage.setItem('shopping-cart-products', JSON.stringify([]));
    }
}

// second parameter id (can be productId) for displaying productData when ProductPage is called
// second parameter id (can be userId) when MyAccount is called
function navigatePage(pageName, id) {
    console.log('navigate to page', pageName);
    const pages = {
        home: new Home(navigatePage),
        shoppingCart: new ShoppingCart(navigatePage),
        productPage: new ProductPage(navigatePage, id),
    };
    console.log(pages);
    pages[pageName].render('#content');
}

function Components() {
    const components = ['navigation', 'login-modal', 'footer'];
    const links = components.map((c) => $(`<script src="components/${c}/${c}.js"></script>`));
    const stylesheets = components.map((c) => $(`<link rel="stylesheet" href="components/${c}/${c}.css">`));
    $('head').prepend(links, stylesheets);
}

function Pages() {
    const pages = ['home', 'shopping-cart', 'product-page'];
    const links = pages.map((c) => $(`<script src="pages/${c}/${c}.js"></script>`));
    const stylesheets = pages.map((c) => $(`<link rel="stylesheet" href="pages/${c}/${c}.css">`));
    $('head').prepend(links, stylesheets);
}

function Services() {
    const services = ['order', 'products', 'user'];
    const scripts = services.map((s) => $(`<script src="services/${s}.js"></script>`));
    $('head').prepend(scripts);
}
