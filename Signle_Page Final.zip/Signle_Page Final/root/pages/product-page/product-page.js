class ProductPage extends Page {
    onClickCallback;
    productId;
    product;
    Products;
    chosenQuantityValue = 1;
    
    constructor(onClickCallback, pId) {
        super('product-page');
        this.onClickCallback = onClickCallback;
        this.productId = pId;
        this.Products = new Products();
    }

    render(parentSelector) {
        this.loadProductData().then(() => {
            const parent = $(parentSelector);
            const newProductPage = $('<div></div>');

            let img = this.product.category + '/'+this.product.img;
            
            newProductPage.load('./pages/product-page/product-page.html', () => {
                newProductPage.find('#product-image').prop('src', `${imagesPath}/${img}`);
                newProductPage.find('#product-title').text(this.product.title);
                newProductPage.find('#product-category').text(this.product.category);
                const productPrice = parseFloat(this.product.price).toFixed(2).replace('.', ',');
                newProductPage.find('#product-price').text(`${productPrice} €`);
                newProductPage.find('#product-description').text(this.product.description);

                $('.nav-item').on('click', (e) => {
                    console.log(`${e.currentTarget.id} was clicked`);
                    if (this.onClickCallback)
                        this.onClickCallback(e.currentTarget.id);
                });

                let chosenQuantityValue;

                $('.dropdown-item').on('click', (e) => {
                    this.chosenQuantityValue = $(e.currentTarget).attr('value');
                    newProductPage.find('#dropdown-product-quantity').text(this.chosenQuantityValue);
                });

                newProductPage.find('#btn-to-shopping-cart').on('click', () => {
                    let img = this.product.category + '/'+this.product.img;
                    $('#product-image-in-shopping-cart').prop('src', `${imagesPath}${img}`);
                    $('#in-shopping-cart-product-title').text(this.product.title);

                    $('#warning-quantity').addClass('d-none');
                    alert("Product has been added in the cart");
                    let shoppingCartProducts = JSON.parse(localStorage.getItem('shopping-cart-products'));
                    let existingProduct = shoppingCartProducts.find(product => product.id === this.productId);
                    if (existingProduct) {
                        existingProduct.quantity = Number(existingProduct.quantity) + Number(this.chosenQuantityValue);
                        shoppingCartProducts.splice(shoppingCartProducts.indexOf(existingProduct), 1);
                        shoppingCartProducts.push(existingProduct);
                    } else {
                        const scProduct = {
                            ...this.product,
                            quantity: parseFloat(this.chosenQuantityValue)
                        };
                        shoppingCartProducts.push(scProduct);
                    }
                    localStorage.setItem('shopping-cart-products', JSON.stringify(shoppingCartProducts));
                    this.renderNavShoppingCart();
                });

                parent.empty().append(newProductPage);
            });
        });
    }

    async loadProductData() {
        this.product = await this.Products.getProductById(this.productId);
    }

    renderNavShoppingCart() {
        let shoppingCartProducts = JSON.parse(localStorage.getItem('shopping-cart-products'));
        if (shoppingCartProducts && 0 < shoppingCartProducts.length) {
            let totalPriceOfSC = 0;
            let totalQuantity = 0;
            shoppingCartProducts.forEach((p) => {
                totalPriceOfSC += parseFloat(p.price) * parseFloat(p.quantity);
                totalQuantity += parseFloat(p.quantity);
            });
            const strTotalPriceOfSC = totalPriceOfSC.toFixed(2).replace('.', ',');

            $('#nav-badge-shopping-cart').html(totalQuantity);
        }
    }
}
