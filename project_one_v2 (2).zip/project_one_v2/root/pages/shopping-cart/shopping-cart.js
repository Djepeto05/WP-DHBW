class ShoppingCart extends Page {
    scProducts;
    scItem;
    subtotalCosts;
    totalCosts;
    User;
    Order;
    onClickCallback;
    user;
    cartItemsList;
    constructor(onClickCallback) {
        super('shopping-cart');
        this.onClickCallback = onClickCallback;
        this.User = new User();
        this.Order = new Order();
        this.cartItemsList = $('<ul id="cart-items"></ul>');
    }

    render(parentSelector) {
        const userId = sessionStorage.getItem('customerID');
        if (!userId) {
            alert('You must login to get to the shopping cart!');
            return;
        }
        this.User.getDatabaseUserById(userId).then(res => {
            this.user = res;

            $(parentSelector).load('./pages/shopping-cart/shopping-cart.html', () => {
                const cartModal = new bootstrap.Modal('#cartModal', {});
                cartModal.show();
                
                this.getShoppingCartProducts();
                this.renderNavShoppingCart();

                if (!this.scProducts.length) {
                    $('#info-no-item-in-sc').css('display', 'block');
                    $('#table').addClass('hide-content');
                } else {
                    $('#info-no-item-in-sc').css('display', 'none');
                    $('#table').removeClass('hide-content');
                    this.scProducts.forEach((cat, index) => {
                        $('#shoppingCartTable').append(`<tr><td >${index + 1}</td><td >${cat['id']}</td><td class="column-heading-wide-2">${cat['title']}</td><td >${cat['quantity']}</td><td><i class="bi bi-trash3-fill btn btn-delete-sc-item"></i></td></tr>`);
                    });

                    $('#costs-subtotal').html(`${this.subtotalCosts}€`);
                    $('#costs-total').html(`${this.totalCosts}€`);

                    $('.btn-delete-sc-item').on('click', (e) => {
                        const chosenProductPosition = $(e.currentTarget.parentElement.parentElement).children(":first").html();
                        this.scProducts.splice(chosenProductPosition - 1, 1);
                        localStorage.setItem('shopping-cart-products', JSON.stringify(this.scProducts));
                        this.renderNavShoppingCart();
                        this.render(parentSelector);
                    });

                    $('#btn-purchase').on('click', (e) => {
                        const customerID = sessionStorage.getItem('customerID');
                        this.scProducts.forEach((item) => {
                            const order = {
                                customerID: customerID,
                                productID: item.id,
                                quantity: item.quantity,
                            };
                            this.Order.getmethodOrder(order).then(response => {
                                if (response.status == 201) {
                                    this.scProducts = [];
                                    localStorage.setItem('shopping-cart-products', JSON.stringify([]));
                                    this.renderNavShoppingCart();
                                    this.onClickCallback('home');
                                    alert("Order has been placed successfully");
                                    $('#cartModal').modal('toggle');
                                }
                            });
                        });
                    });
                }

                $('.form-check-input').on('click', (e) => {

                });

            });
        }).catch(res => console.log(res));
    }

    getShoppingCartProducts() {
        this.scProducts = JSON.parse(localStorage.getItem('shopping-cart-products'));
    }

    renderNavShoppingCart() {
        let shoppingCartProducts = this.scProducts;
        if (shoppingCartProducts) {
            let totalPriceOfSC = 0;
            let totalQuantity = 0;
            shoppingCartProducts.forEach((p) => {
                totalPriceOfSC += parseFloat(p.price) * parseFloat(p.quantity);
                totalQuantity
                += parseFloat(p.quantity);
            });
    
            this.totalCosts = (Number(totalPriceOfSC.toFixed(2))).toString().replace('.', ',');
            const strTotalPriceOfSC = totalPriceOfSC.toFixed(2).replace('.', ',');
    
            this.subtotalCosts = strTotalPriceOfSC;
            if (totalQuantity == 0) totalQuantity = '';
            $('#nav-badge-shopping-cart').html(totalQuantity);
        }
    }
    
    show(title, content, onFinishedCallback) {
        let cartModal = $('#cartModal');
        if (cartModal.length === 0) {
            this.render(parentSelector, () => {
                cartModal = $('#cartModal');
                this.setTexts(title, content, cartModal);
    
                cartModal.on('click', (clickArguments) => {
                    if (clickArguments.target.id === cartModal.get(0).id) {
                        this.hide();
                    }
                });
    
                cartModal.find('.cart-confirm').on('click', () => {
                    this.hide();
                    onFinishedCallback(true);
                });
    
                cartModal.find('.cart-cancel').on('click', () => {
                    this.hide();
                    onFinishedCallback(false);
                });
            });
        } else {
            this.setTexts(title, content, cartModal);
            cartModal.addClass('visible');
        }
    }
    
    setTexts(title, content, cartModal) {
        setTimeout(() => cartModal.addClass('visible'), 1);
        cartModal.find('.cart-title').text(title);
        cartModal.find('.cart-content').text(content);
        cartModal.find('.cart-content').append(this.cartItemsList);
    }
    
    addItem(product) {
        const cartProduct = $('<li></li>').text(product.title);
        cartProduct.text(product.title + " ");
        const removeButton = $('<button class="cart-remove">Remove</button>');
    
        removeButton.on('click', () => {
            cartProduct.remove();
        });
    
        cartProduct.append(removeButton);
        this.cartItemsList.append(cartProduct);
    }
    
    hide() {
        const cartModal = $('#cartModal');
        cartModal.removeClass('visible');
    }
}    