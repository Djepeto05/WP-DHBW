class Order {

    baseUrl = 'http://localhost/2023/order.php';

    constructor() {

    }

    async getmethodOrder(newContent){
        console.log('post database content', newContent);
        const result = await fetch(this.baseUrl, {
            method: 'POST',
            cache: 'reload',
            body: JSON.stringify(newContent),
        })
        console.log(result);
        return result;
    }
}