<?php
    session_start();
    include('config.php');
    if (isset($_POST)) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        $query = $connection->prepare("SELECT * FROM users WHERE email=:email");
        $query->bindParam("email", $email, PDO::PARAM_STR);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);
        if (!$result) {
            header("Location: signin.html?msg=Email password combination is wrong!");
        } else {
            if (password_verify($password, $result['password'])) {
                $_SESSION['user_id'] = $result['id'];
                header("Location: signin.html?msg=Congratulations, you are logged in!");
            } else {
                header("Location: signin.html?msg=Invalid credentials");
            }
        }
    }
?>