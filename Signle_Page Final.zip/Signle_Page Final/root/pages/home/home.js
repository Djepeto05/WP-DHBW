class Home extends Page {
    Products;
    carouselCardProducts;
    onClickCallback;
    constructor(onClickCallback) {
        super('home');
        this.Products = new Products();
        this.onClickCallback = onClickCallback;
    }

    render(parentSelector) {
        $(parentSelector).load('./pages/home/home.html', () => {
            this.loadCarouselCardProducts().then((products) => {
                this.renderCarouselCards(products);

                $('.product-item').on('click', (e) => {
                    if (this.onClickCallback) {
                        this.onClickCallback('productPage', e.currentTarget.id);
                    }
                })

            });
            this.setupListeners();
        });

    }

    async loadCarouselCardProducts() {
        const allProducts = await this.Products.getAllProducts();
        return allProducts;
    }

    renderCarouselCards(products) {
        console.log(products);
        $('.products_box').html('');

        for (let index = 0; index < products.length; index++) {
            let img = products[index].category + '/'+products[index].img;
            const element = `<div class="col-lg-4 product-item-parent category_Home category_${products[index].category}">
            <div class="mt-5 product-item" id="${products[index].id}">
                <img src="${imagesPath}${img}" class="card-img-top" alt="...">
                <div class="card-body">
                        <h5 class="card-title">${products[index].title}</h5>
                        <p class="card-text">${products[index].description}</p>
                    </div>
                </div>
            </div>`;
            $('.products_box').append(element);
            
            if($('.category-btn.active').length > 0 && (index + 1) == products.length){
                let id = $('.category-btn.active').attr('id');
                $('.category-btn').removeClass('active');
                $('#'+id).addClass('active');
                $('.product-item-parent').hide();
                console.log(this.capitalizeFirstLetter(id));
                $('.category_'+this.capitalizeFirstLetter(id)).show();
            }
            
        }

    }

    capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    setupListeners() {
        const categoryBtn = $('.category-btn');
        
        categoryBtn.on('click', (e) => {
            if($('body').find('.products_box').length == 0){
                this.onClickCallback('home');
            }
            $('.category-btn').removeClass('active');
            $('#'+e.currentTarget.id).addClass('active');
            $('.product-item-parent').hide();
            console.log(this.capitalizeFirstLetter(e.currentTarget.id));
            $('.category_'+this.capitalizeFirstLetter(e.currentTarget.id)).show();

        });

    }

}
